A vehicle resale system where users can list their vehicle or buy an vehicle
